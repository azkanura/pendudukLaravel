<?php

namespace App\Http\Controllers;

use App\User;
use App\Http\Controllers\Controller;
use \GuzzleHttp\Client;

class ApiController extends Controller
{
    
    public function getDataPenduduk($nik)
    {
        $client = new Client();
        $res = $client->request('GET', 'https://api.github.com/repos/guzzle/guzzle');
		return $res->getStatusCode();
    }
}